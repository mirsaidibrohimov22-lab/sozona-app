// lib/features/student/home/presentation/widgets/learning_stats_card.dart
// So'zona — O'quv statistikasi kartochkasi
// Bugungi flashcard, quiz, listening mashqlari soni

import 'package:flutter/material.dart';

import 'package:my_first_app/core/constants/app_colors.dart';
import 'package:my_first_app/core/constants/app_sizes.dart';
import 'package:my_first_app/core/widgets/app_card.dart';

/// Bugungi o'quv statistikasi
class LearningStatsCard extends StatelessWidget {
  final int flashcardsDone;
  final int quizzesDone;
  final int listeningDone;
  final int weakItemsCount;

  const LearningStatsCard({
    super.key,
    required this.flashcardsDone,
    required this.quizzesDone,
    required this.listeningDone,
    required this.weakItemsCount,
  });

  @override
  Widget build(BuildContext context) {
    return AppCard.outlined(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Bugungi statistika',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),

          const SizedBox(height: AppSizes.spacingMd),

          // 2x2 grid
          Row(
            children: [
              Expanded(
                child: _StatItem(
                  icon: '📝',
                  label: 'Kartochka',
                  value: flashcardsDone,
                  color: AppColors.primary,
                ),
              ),
              const SizedBox(width: AppSizes.spacingMd),
              Expanded(
                child: _StatItem(
                  icon: '🧠',
                  label: 'Quiz',
                  value: quizzesDone,
                  color: AppColors.secondary,
                ),
              ),
            ],
          ),

          const SizedBox(height: AppSizes.spacingMd),

          Row(
            children: [
              Expanded(
                child: _StatItem(
                  icon: '🎧',
                  label: 'Tinglash',
                  value: listeningDone,
                  color: AppColors.accent,
                ),
              ),
              const SizedBox(width: AppSizes.spacingMd),
              Expanded(
                child: _StatItem(
                  icon: '💪',
                  label: 'Zaif so\'zlar',
                  value: weakItemsCount,
                  color: AppColors.warning,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// Bitta statistika elementi
class _StatItem extends StatelessWidget {
  final String icon;
  final String label;
  final int value;
  final Color color;

  const _StatItem({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSizes.spacingMd),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(AppSizes.radiusSm),
      ),
      child: Row(
        children: [
          Text(icon, style: const TextStyle(fontSize: 24)),
          const SizedBox(width: AppSizes.spacingSm),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '$value',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
              Text(
                label,
                style: const TextStyle(
                  fontSize: 11,
                  color: AppColors.textSecondary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
