// lib/features/student/home/presentation/screens/student_home_screen.dart
// So'zona — O'quvchi bosh sahifasi
// ✅ TUZATILDI: AI Motivation banner qo'shildi
// ✅ TUZATILDI: dynamic → UserEntity? (oldingi fix saqlanadi)

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'package:my_first_app/core/constants/app_colors.dart';
import 'package:my_first_app/core/constants/app_sizes.dart';
import 'package:my_first_app/core/widgets/app_avatar.dart';
import 'package:my_first_app/core/widgets/app_loading_widget.dart';
import 'package:my_first_app/core/widgets/app_error_widget.dart';
import 'package:my_first_app/features/auth/domain/entities/user_entity.dart';
import 'package:my_first_app/features/auth/presentation/providers/auth_provider.dart';
import 'package:my_first_app/features/student/home/presentation/providers/student_home_provider.dart';
import 'package:my_first_app/features/student/home/presentation/widgets/daily_plan_card.dart';
import 'package:my_first_app/features/student/home/presentation/widgets/quick_actions_widget.dart';
import 'package:my_first_app/features/student/home/presentation/widgets/streak_card.dart';
import 'package:my_first_app/features/student/home/presentation/widgets/learning_stats_card.dart';
import 'package:my_first_app/features/student/home/presentation/widgets/level_progress_widget.dart';
import 'package:my_first_app/features/student/home/presentation/widgets/recommended_lesson_card.dart';

/// O'quvchi bosh sahifasi
class StudentHomeScreen extends ConsumerStatefulWidget {
  const StudentHomeScreen({super.key});

  @override
  ConsumerState<StudentHomeScreen> createState() => _StudentHomeScreenState();
}

class _StudentHomeScreenState extends ConsumerState<StudentHomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final user = ref.read(authNotifierProvider).user;
      ref.read(studentHomeProvider.notifier).loadHomeData(user);
    });
  }

  @override
  Widget build(BuildContext context) {
    final homeState = ref.watch(studentHomeProvider);
    final authState = ref.watch(authNotifierProvider);
    final UserEntity? user = authState.user;

    return Scaffold(
      body: SafeArea(
        child: homeState.isLoading
            ? const AppLoadingWidget()
            : homeState.error != null
                ? AppErrorWidget(
                    message: homeState.error!,
                    onRetry: () => ref
                        .read(studentHomeProvider.notifier)
                        .loadHomeData(user),
                  )
                : RefreshIndicator(
                    onRefresh: () =>
                        ref.read(studentHomeProvider.notifier).refresh(),
                    child: _buildContent(context, homeState, user),
                  ),
      ),
    );
  }

  Widget _buildContent(
    BuildContext context,
    StudentHomeState homeState,
    UserEntity? user,
  ) {
    return CustomScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      slivers: [
        // ── Header ──
        SliverToBoxAdapter(
          child: _buildHeader(context, user),
        ),

        // ── ✅ YANGI: AI Motivation Banner ──
        if (homeState.motivation != null)
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSizes.spacingLg,
              ),
              child: _MotivationBannerWidget(
                message: homeState.motivation!.message,
                onDismiss: () {
                  ref.read(studentHomeProvider.notifier).dismissMotivation();
                },
              ),
            ),
          ),

        if (homeState.motivation != null)
          const SliverToBoxAdapter(
            child: SizedBox(height: AppSizes.spacingMd),
          ),

        // ── Streak va Kunlik reja ──
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppSizes.spacingLg,
            ),
            child: Row(
              children: [
                Expanded(
                  child: StreakCard(streak: homeState.streak),
                ),
                const SizedBox(width: AppSizes.spacingMd),
                Expanded(
                  child: DailyPlanCard(dailyPlan: homeState.dailyPlan),
                ),
              ],
            ),
          ),
        ),

        const SliverToBoxAdapter(
          child: SizedBox(height: AppSizes.spacingLg),
        ),

        // ── Daraja progressi ──
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppSizes.spacingLg,
            ),
            child: LevelProgressWidget(
              level: user?.level.name.toUpperCase() ?? 'A1',
              xp: homeState.totalXp,
              xpForNextLevel: 500,
            ),
          ),
        ),

        const SliverToBoxAdapter(
          child: SizedBox(height: AppSizes.spacingXl),
        ),

        // ── Tezkor harakatlar ──
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppSizes.spacingLg,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Mashq qilish',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
                const SizedBox(height: AppSizes.spacingMd),
                const QuickActionsWidget(),
              ],
            ),
          ),
        ),

        const SliverToBoxAdapter(
          child: SizedBox(height: AppSizes.spacingXl),
        ),

        // ── O'quv statistikasi ──
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppSizes.spacingLg,
            ),
            child: LearningStatsCard(
              flashcardsDone: homeState.dailyPlan.flashcardsDone,
              quizzesDone: homeState.dailyPlan.quizzesDone,
              listeningDone: homeState.dailyPlan.listeningDone,
              weakItemsCount: homeState.weakItemsCount,
            ),
          ),
        ),

        const SliverToBoxAdapter(
          child: SizedBox(height: AppSizes.spacingXl),
        ),

        // ── Tavsiya etilgan darslar ──
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppSizes.spacingLg,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Sizga tavsiya',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
                const SizedBox(height: AppSizes.spacingMd),
                const RecommendedLessonCard(),
              ],
            ),
          ),
        ),

        // Pastki bo'sh joy
        const SliverToBoxAdapter(
          child: SizedBox(height: AppSizes.spacingXxl),
        ),
      ],
    );
  }

  /// Header — salom va avatar
  Widget _buildHeader(BuildContext context, UserEntity? user) {
    final greeting = _getGreeting();

    return Padding(
      padding: const EdgeInsets.all(AppSizes.spacingLg),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  greeting,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppColors.textSecondary,
                      ),
                ),
                const SizedBox(height: 2),
                Text(
                  user?.displayName ?? 'Foydalanuvchi',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ],
            ),
          ),
          // Profil faqat bottom nav orqali ochiladi
          AppAvatar(
            name: user?.displayName ?? 'U',
            imageUrl: user?.photoUrl,
            size: AvatarSize.medium,
          ),
        ],
      ),
    );
  }

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Xayrli tong! ☀️';
    if (hour < 17) return 'Xayrli kun! 🌤️';
    if (hour < 21) return 'Xayrli kech! 🌙';
    return 'Xayrli tun! 🌃';
  }
}

// ═══════════════════════════════════════════════════════════════
// ✅ YANGI: Motivation Banner Widget (dismiss bilan)
// ═══════════════════════════════════════════════════════════════
class _MotivationBannerWidget extends StatefulWidget {
  final String message;
  final VoidCallback onDismiss;

  const _MotivationBannerWidget({
    required this.message,
    required this.onDismiss,
  });

  @override
  State<_MotivationBannerWidget> createState() =>
      _MotivationBannerWidgetState();
}

class _MotivationBannerWidgetState extends State<_MotivationBannerWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOut,
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, -0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    ));

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _dismiss() {
    _controller.reverse().then((_) {
      if (mounted) widget.onDismiss();
    });
  }

  @override
  Widget build(BuildContext context) {
    return SlideTransition(
      position: _slideAnimation,
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [AppColors.primary, Color(0xFF7C3AED)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: AppColors.primary.withValues(alpha: 0.25),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('🤖', style: TextStyle(fontSize: 28)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'AI Coach',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      widget.message,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: _dismiss,
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.close,
                    color: Colors.white70,
                    size: 16,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
