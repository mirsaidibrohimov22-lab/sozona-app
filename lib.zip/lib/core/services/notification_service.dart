// QO'YISH: lib/core/services/notification_service.dart
// So'zona — Push notification servisi (FCM)

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:my_first_app/core/services/logger_service.dart';

/// Background message handler (top-level function bo'lishi SHART)
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  LoggerService.info('Background xabar: ${message.messageId}');
}

class NotificationService {
  NotificationService._();

  static final FirebaseMessaging _messaging = FirebaseMessaging.instance;

  static Future<void> init() async {
    // Background handler ro'yxatdan o'tkazish
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

    // Ruxsat so'rash
    final settings = await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      provisional: false,
    );

    LoggerService.info('Notification ruxsati: ${settings.authorizationStatus}');

    // Foreground xabarlarni tinglash
    FirebaseMessaging.onMessage.listen(_handleForegroundMessage);

    // Ilova ochilganda xabardan kelgan holat
    FirebaseMessaging.onMessageOpenedApp.listen(_handleMessageOpenedApp);
  }

  static void _handleForegroundMessage(RemoteMessage message) {
    LoggerService.info('Foreground xabar: ${message.notification?.title}');
    // SnackBar yoki in-app notification ko'rsatish
  }

  static void _handleMessageOpenedApp(RemoteMessage message) {
    LoggerService.info('Xabardan ochildi: ${message.data}');
    // Route ga yo'naltirish — data['actionRoute'] orqali
  }

  /// FCM token olish (Firestore ga saqlash uchun)
  static Future<String?> getToken() async {
    try {
      return await _messaging.getToken();
    } catch (e) {
      LoggerService.error('FCM token xatoligi', error: e);
      return null;
    }
  }

  /// Token yangilanishlarini tinglash
  static void listenTokenRefresh(Function(String) onRefresh) {
    _messaging.onTokenRefresh.listen(onRefresh);
  }

  /// Mavzu (topic) ga obuna bo'lish
  static Future<void> subscribeToTopic(String topic) async {
    try {
      await _messaging.subscribeToTopic(topic);
    } catch (e) {
      LoggerService.error('Topic obuna xatoligi', error: e);
    }
  }

  /// Mavzudan chiqish
  static Future<void> unsubscribeFromTopic(String topic) async {
    try {
      await _messaging.unsubscribeFromTopic(topic);
    } catch (e) {
      LoggerService.error('Topic chiqish xatoligi', error: e);
    }
  }
}
